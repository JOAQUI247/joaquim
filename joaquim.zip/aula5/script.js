function detecta(event){
    let tecla = event.key;
    if (tecla =="a" )
    alert("você apertou 'a'")

    if (tecla =="e" )
    alert("você apertou 'e'")

    if (tecla =="i" )
    alert("você apertou 'i'")

    if (tecla =="o" )
    alert("você apertou 'o'")

    if (tecla =="o" )
    alert("você apertou 'u'")

    if (tecla =="u" )
    alert("você apertou 'o'")
}

<p id="hide" style="display: block;">posso sumir!</p>

document.getElementById("hide").style.display = "none" ;