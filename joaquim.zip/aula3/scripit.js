const pessoa = {};

function mostrar() {
    let resultado = document.getElementById
    ('resultado')
    console.log( resultado );

    resultado.style.display = "block"

    let nome = document.getElementById('nome').value;
}